import os
import telegram
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

# Exemple de value bet à envoyer (à personnaliser plus tard)
message = "🎾 Value Bet Tennis du jour :\nMatch : Djokovic vs Alcaraz\nPari : Alcaraz gagne\nCote : 2.10\nConfiance : 7/10"

bot = telegram.Bot(token=TOKEN)
bot.send_message(chat_id=CHAT_ID, text=message)
